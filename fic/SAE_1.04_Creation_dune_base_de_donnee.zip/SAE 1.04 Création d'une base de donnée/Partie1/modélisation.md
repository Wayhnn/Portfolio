# Modélisation des:

## Parcours (Annexe 2)

- .id_parcours (PK)
- .libelle_parcours
- .id_competences_parcours (FK)
- .ressources
- .sae

## Compétences (Annexe 1 / Annexe 3)

- .id_competence (PK)
- .libelle_competence
- .annee_competences
- .id_UE (FK)

## Activités (Annexe 4)

- .id_activite (PK)
- .libelle_activite
- .id_semestre (FK)

## UE (Annexe 3)

- .libelle_UE
- .id_UE (PK)

## Semestre (Annexe 5-6-7)

- .no_semestre (PK)

## Niveau (Annexe 2)

- .id_niveau (PK)